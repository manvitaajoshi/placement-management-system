from django.apps import AppConfig


class OurOwnPortalConfig(AppConfig):
    name = 'our_own_portal'